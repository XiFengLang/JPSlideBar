//
//  JPSlideBar+ScrollViewDelegate.h
//  JPSlideBar
//
//  Created by apple on 16/1/16.
//  Copyright © 2016年 XiFengLang. All rights reserved.
//

#import "JPSlideBar.h"

@interface JPSlideBar (ScrollViewDelegate)

@end
